# MiventSoft API (backend para la app Android)

API REST minima en Node.js + Express que sirve de puente entre la app Android
(vendedor en campo) y la base de datos SQL Server de Kaili Industrial. Usa los
**mismos stored procedures** que el sistema de escritorio (nada de logica de
negocio nueva ni cambios en la base de datos) y agrega login con token (JWT)
en vez de que cada celular tenga la contrasena real de la base de datos.

## Por que existe esta API (y no Android -> SQL Server directo)

Conectar la app Android directo al SQL Server de la nube implicaria: exponer
el puerto de SQL Server a todo internet (los celulares no tienen IP fija para
poner en una whitelist), o repartir la contrasena real de la base de datos
dentro del APK / a cada usuario (un APK se puede decompilar y sacar cualquier
string). Con esta API, el celular nunca conoce la contrasena de SQL Server:
solo tiene un token que se puede revocar por usuario sin afectar a los demas.

## Como correrla

```bash
npm install
cp .env.example .env
# editar .env con los datos reales de conexion (NO subir este archivo a git)
npm start
```

Health check: `GET /api/health`

## Variables de entorno (.env)

Ver `.env.example`. Nunca commitear `.env` (ya esta en `.gitignore`).

## Endpoints (v1 - "Vendedor en campo")

Todos menos `/api/auth/login` requieren header `Authorization: Bearer <token>`.

| Metodo | Ruta | SP que usa | Descripcion |
|---|---|---|---|
| POST | `/api/auth/login` | `Usuarios` (query directa) | Login, devuelve JWT |
| GET | `/api/clientes?buscar=texto` | `MAM_Clientes @tipo=10` | Listar/buscar clientes |
| GET | `/api/productos/venta?sucursalId=&categoriaVentaId=` | `MAM_Ventas @tipo=5` | Productos disponibles para vender |
| POST | `/api/ventas` | `MAM_Ventas @tipo=1` | Registrar una venta nueva |
| GET | `/api/cobros/pendientes` | `MAM_CreditosVentas @tipo=3` | Deudas de clientes con saldo pendiente |
| POST | `/api/cobros` | `MAM_CreditosVentas @tipo=4` | Registrar un pago/abono |

## Pendiente / decisiones abiertas (hablar con Marco antes de ir a produccion)

1. **Rotar la contrasena del usuario `marco` en cloudclusters.net.** Se pego
   en el chat en texto plano en algun momento; hasta que se confirme que fue
   rotada, no se debe usar ese usuario/password en el `.env` real.
2. **Venta a credito:** se revisaron todos los stored procedures y todo
   `AccesoLogica.vb` y no se encontro donde se crea la fila en la tabla
   `CreditosVentas` cuando una venta es a credito. Mientras esto no se aclare,
   la recomendacion es que la app Android v1 solo ofrezca venta **al
   contado**. El endpoint `POST /api/ventas` no bloquea el campo `tipoVenta`
   por codigo (no se van a inventar numeros magicos sin verificar), pero no
   se debe habilitar esa opcion en la interfaz de Android todavia.
3. **Contrasenas en texto plano:** la tabla `Usuarios` guarda la contrasena
   sin hash (heredado del sistema actual) y el login de escritorio tiene un
   problema de inyeccion SQL por concatenar el usuario/password directo en el
   query (`L_Validar_Usuario` en `AccesoLogica.vb`). Esta API ya usa consultas
   parametrizadas (sin inyeccion), pero sigue comparando contra texto plano
   porque asi esta guardada la contrasena hoy. Migrar a hash (bcrypt) requiere
   coordinar tambien un cambio en el sistema de escritorio.
4. **Limitacion heredada en la lista de productos para vender**
   (`MAM_Ventas @tipo=5`): usa INNER JOIN contra stock/precio/atributo, asi
   que un producto sin fila de stock para esa sucursal, sin precio para esa
   categoria, o sin atributo asignado, no aparece para venderse (mismo
   problema que ya se detecto antes en `MAM_Movimientos`). No se cambia el SP
   sin que Marco lo decida aparte.

## Estilo del codigo

Cada archivo tiene comentarios explicando el "por que", no solo el "que".
Rutas y logica de negocio separadas en `src/routes/*.js`; nada de ORMs ni
abstracciones raras, consultas directas con el driver `mssql` para que sea
facil de leer y modificar.
