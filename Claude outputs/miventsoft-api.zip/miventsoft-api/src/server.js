// server.js
// Punto de entrada de la API. Junta todo: middlewares, rutas, manejo de errores.

require("dotenv").config();

const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth.routes");
const clientesRoutes = require("./routes/clientes.routes");
const productosRoutes = require("./routes/productos.routes");
const ventasRoutes = require("./routes/ventas.routes");
const cobrosRoutes = require("./routes/cobros.routes");

const app = express();

app.use(cors());
app.use(express.json());

// Endpoint simple para probar que el servidor esta vivo (util para
// revisar el deploy en Azure/Render/etc sin tener que loguearse).
app.get("/api/health", (req, res) => {
  res.json({ ok: true, hora: new Date().toISOString() });
});

app.use("/api/auth", authRoutes);
app.use("/api/clientes", clientesRoutes);
app.use("/api/productos", productosRoutes);
app.use("/api/ventas", ventasRoutes);
app.use("/api/cobros", cobrosRoutes);

// Ruta no encontrada
app.use((req, res) => {
  res.status(404).json({ error: "Ruta no encontrada." });
});

// Manejador de errores CENTRAL. Cualquier error que pase (de la BD, de
// una ruta, lo que sea) termina aca gracias a asyncHandler.
//
// Regla de seguridad: al cliente (la app Android) le mandamos un mensaje
// generico. El detalle completo (que puede incluir texto del error SQL)
// solo se imprime en el log del servidor, nunca se lo mandamos al
// celular ni lo guardamos con datos de usuario/password.
app.use((err, req, res, next) => {
  console.error("Error no manejado:", err);
  res.status(500).json({ error: "Ocurrio un error en el servidor. Intenta de nuevo." });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`API MiventSoft escuchando en el puerto ${PORT}`);
});
