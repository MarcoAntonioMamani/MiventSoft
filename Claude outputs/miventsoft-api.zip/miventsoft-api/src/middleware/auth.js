// auth.js
// Middleware que reemplaza al "L_Usuario" global del sistema de escritorio.
//
// En el sistema viejo (VB.NET), habia una sola variable compartida
// (Public Shared L_Usuario) con el usuario logueado, porque el programa
// corria un usuario a la vez en la PC de cada vendedor.
//
// Aqui NO podemos hacer eso: un solo servidor Node atiende a TODOS los
// celulares al mismo tiempo. Si usaramos una variable global, el usuario
// de un celular se mezclaria con el de otro. Por eso cada request trae
// su propio token (JWT), y de ese token sacamos quien es el usuario
// ANTES de tocar la base de datos.

const jwt = require("jsonwebtoken");

// Se usa en las rutas que necesitan un usuario logueado.
// Lee el header: Authorization: Bearer <token>
function requiereLogin(req, res, next) {
  const authHeader = req.headers["authorization"] || "";
  const [tipo, token] = authHeader.split(" ");

  if (tipo !== "Bearer" || !token) {
    return res.status(401).json({ error: "Falta el token de autenticacion." });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    // Dejamos los datos del usuario disponibles para el resto de la ruta,
    // en req.usuario (equivalente moderno del viejo L_Usuario, pero
    // aislado por request en vez de global).
    req.usuario = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: "Token invalido o vencido." });
  }
}

module.exports = { requiereLogin };
