// ventas.routes.js
// Registrar una venta nueva (pantalla principal del vendedor, con
// escaneo de codigo de barras armando el carrito en el celular).
//
// Usa el mismo SP que el sistema de escritorio: MAM_Ventas @tipo=1.
// Ese SP necesita DOS tablas (TVP - Table Valued Parameters):
//   - VentaDetalle02Type: el detalle de productos vendidos (el "carrito")
//   - VentaMonedaType: como se cobro (efectivo en Bs, dolares, tarjeta, etc)
//
// *** IMPORTANTE - esto hay que resolverlo con Marco antes de habilitar
// venta A CREDITO desde el celular ***
// Se reviso TODO el script de la base de datos y TODO AccesoLogica.vb
// buscando donde se crea la fila en la tabla CreditosVentas cuando una
// venta es a credito, y no se encontro ningun INSERT INTO CreditosVentas
// en ningun lado (ni en MAM_Ventas, ni en MAM_CreditosVentas, ni en el
// codigo VB). Osea: no esta claro donde/como se crea ese registro hoy en
// el sistema real. Mientras no se confirme eso, esta API deja pasar el
// campo tipoVenta tal cual se lo manden (no inventamos numeros magicos
// de "contado" vs "credito" porque no estan verificados), pero
// RECOMIENDO que la app Android v1 solo ofrezca venta al CONTADO, para
// no crear ventas "a credito" que despues no aparezcan en Cobros
// Pendientes por faltar su fila en CreditosVentas.

const express = require("express");
const { getPool, sql } = require("../db");
const { requiereLogin } = require("../middleware/auth");
const asyncHandler = require("../utils/asyncHandler");

const router = express.Router();

router.post(
  "/",
  requiereLogin,
  asyncHandler(async (req, res) => {
    const {
      sucursalId,
      fechaVenta,
      tipoVenta,
      fechaVencimientoCredito,
      clienteId,
      monedaVenta,
      estado,
      glosa,
      descuento,
      totalVenta,
      facturado,
      productos, // [{ productoId, cantidad, precio, subtotal, descuentoPorcentaje, descuentoMonto, total, detalle, precioCosto, lote, fechaVencimiento, tipo, kitId, cantidadKit }]
      pagos, // [{ montoBs, montoDolares, tarjetaBancaria, transferenciaBancaria, tipoCambio }]
    } = req.body;

    if (!sucursalId || !clienteId || !Array.isArray(productos) || productos.length === 0) {
      return res.status(400).json({
        error: "Faltan datos obligatorios: sucursalId, clienteId y al menos un producto.",
      });
    }

    // Tabla de detalle de productos (VentaDetalle02Type).
    // Ojo: hay que agregar las columnas en el MISMO ORDEN y TIPO que
    // definimos en el CREATE TYPE de la base, si no SQL Server tira error.
    const detalleTable = new sql.Table("VentaDetalle02Type");
    detalleTable.columns.add("Id", sql.Int);
    detalleTable.columns.add("VentaId", sql.Int);
    detalleTable.columns.add("ProductoId", sql.Int);
    detalleTable.columns.add("Producto", sql.NVarChar(500));
    detalleTable.columns.add("Cantidad", sql.Decimal(18, 2));
    detalleTable.columns.add("Precio", sql.Decimal(18, 2));
    detalleTable.columns.add("Subtotal", sql.Decimal(18, 2));
    detalleTable.columns.add("PorcentajeDescuento", sql.Decimal(18, 2));
    detalleTable.columns.add("MontoDescuento", sql.Decimal(18, 2));
    detalleTable.columns.add("Total", sql.Decimal(18, 2));
    detalleTable.columns.add("Detalle", sql.NVarChar(450));
    detalleTable.columns.add("PrecioCosto", sql.Decimal(18, 2));
    detalleTable.columns.add("Lote", sql.NVarChar(50));
    detalleTable.columns.add("FechaVencimiento", sql.Date);
    detalleTable.columns.add("Tipo", sql.Int);
    detalleTable.columns.add("TipoNombre", sql.NVarChar(350));
    detalleTable.columns.add("KitId", sql.Int);
    detalleTable.columns.add("KitNombre", sql.NVarChar(350));
    detalleTable.columns.add("CantidadKit", sql.Int);
    detalleTable.columns.add("estado", sql.Int);
    detalleTable.columns.add("img", sql.Image);
    detalleTable.columns.add("stock", sql.Decimal(18, 2));

    for (const p of productos) {
      detalleTable.rows.add(
        null, // Id (no se usa al insertar, el SP no lo lee de aca)
        null, // VentaId (lo pone el SP con @Id)
        p.productoId,
        p.nombreProducto ?? null,
        p.cantidad,
        p.precio,
        p.subtotal,
        p.descuentoPorcentaje ?? 0,
        p.descuentoMonto ?? 0,
        p.total,
        p.detalle ?? "",
        p.precioCosto ?? 0,
        p.lote ?? null,
        p.fechaVencimiento ?? null,
        p.tipo ?? 1, // 1 = producto normal, 2 = kit
        null,
        p.kitId ?? null,
        null,
        p.cantidadKit ?? null,
        0, // estado (el SP filtra por estado >= 0, mandamos 0 = activo)
        null,
        null
      );
    }

    // Tabla de pagos (VentaMonedaType).
    const pagosTable = new sql.Table("VentaMonedaType");
    pagosTable.columns.add("Id", sql.Int);
    pagosTable.columns.add("VentaId", sql.Int);
    pagosTable.columns.add("MontoBs", sql.Decimal(18, 2));
    pagosTable.columns.add("MontoDolares", sql.Decimal(18, 2));
    pagosTable.columns.add("TarjetaBancaria", sql.Decimal(18, 2));
    pagosTable.columns.add("TransferenciaBancaria", sql.Decimal(18, 2));
    pagosTable.columns.add("TipoCambio", sql.Decimal(18, 2));
    pagosTable.columns.add("Estado", sql.Int);

    const listaPagos = Array.isArray(pagos) && pagos.length > 0 ? pagos : [{}];
    for (const pago of listaPagos) {
      pagosTable.rows.add(
        null,
        null,
        pago.montoBs ?? 0,
        pago.montoDolares ?? 0,
        pago.tarjetaBancaria ?? 0,
        pago.transferenciaBancaria ?? 0,
        pago.tipoCambio ?? 0,
        0 // el SP filtra por estado = 0
      );
    }

    const pool = await getPool();

    const resultado = await pool
      .request()
      .input("tipo", sql.Int, 1)
      .input("SucursalId", sql.Int, sucursalId)
      .input("FechaVenta", sql.Date, fechaVenta ?? new Date())
      .input("PersonalId", sql.Int, req.usuario.idPersonal)
      .input("TipoVenta", sql.Int, tipoVenta)
      .input("FechaVencimientoCredito", sql.Date, fechaVencimientoCredito ?? null)
      .input("ClienteId", sql.Int, clienteId)
      .input("MonedaVenta", sql.Int, monedaVenta ?? 1)
      .input("Estado", sql.Int, estado ?? 1)
      .input("Glosa", sql.NVarChar(450), glosa ?? "")
      .input("Descuento", sql.Decimal(18, 2), descuento ?? 0)
      .input("TotalVenta", sql.Decimal(18, 2), totalVenta)
      .input("VentaDetalleType", detalleTable)
      .input("usuario", sql.NVarChar(50), req.usuario.nombreUsuario)
      .input("VentaPagos", pagosTable)
      .input("Facturado", sql.Int, facturado ?? 0)
      .execute("MAM_Ventas");

    const nuevaVentaId = resultado.recordset?.[0]?.newNumi;

    res.status(201).json({ ventaId: nuevaVentaId });
  })
);

module.exports = router;
