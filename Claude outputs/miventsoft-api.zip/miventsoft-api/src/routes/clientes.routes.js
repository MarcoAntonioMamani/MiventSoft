// clientes.routes.js
// Listado y busqueda de clientes para el vendedor en campo.
//
// Usa el mismo SP que el sistema de escritorio: MAM_Clientes @tipo=10.
// Ese SP no tiene un parametro de busqueda por texto, asi que filtramos
// aqui mismo en Node (sobre los datos ya traidos). Si la tabla Clientes
// crece mucho en el futuro y esto se pone lento, se puede pedir agregar
// un @tipo nuevo al SP con filtro por nombre directo en el WHERE.
//
// Nota: el SP le pone de alias "NombreProveedor" al nombre del cliente
// (asi esta escrito en la base, probablemente copiado de otro modulo).
// Aqui lo devolvemos ya renombrado a "nombreCliente" para que el
// Android no tenga que lidiar con ese nombre confuso.

const express = require("express");
const { getPool, sql } = require("../db");
const { requiereLogin } = require("../middleware/auth");
const asyncHandler = require("../utils/asyncHandler");

const router = express.Router();

router.get(
  "/",
  requiereLogin,
  asyncHandler(async (req, res) => {
    const pool = await getPool();

    const resultado = await pool
      .request()
      .input("tipo", sql.Int, 10)
      .execute("MAM_Clientes");

    let clientes = resultado.recordset.map((c) => ({
      id: c.Id,
      nombreCliente: c.NombreProveedor,
      direccion: c.DireccionCliente,
      telefono: c.Telefono,
    }));

    const buscar = (req.query.buscar || "").trim().toLowerCase();
    if (buscar) {
      clientes = clientes.filter((c) =>
        (c.nombreCliente || "").toLowerCase().includes(buscar)
      );
    }

    res.json(clientes);
  })
);

module.exports = router;
