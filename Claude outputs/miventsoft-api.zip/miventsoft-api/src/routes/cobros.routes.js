// cobros.routes.js
// Cobros pendientes: ver que clientes deben plata, y registrar un pago
// cuando el vendedor cobra en la calle.
//
// GET /pendientes  -> MAM_CreditosVentas @tipo=3 (lista deudas con saldo > 0)
// POST /            -> MAM_CreditosVentas @tipo=4 (registra un pago/abono)
//
// Estos dos SPs solo LEEN y ACTUALIZAN creditos que ya existen en la
// tabla CreditosVentas. No crean creditos nuevos (ver la nota grande en
// ventas.routes.js sobre el vacio que encontramos ahi).

const express = require("express");
const { getPool, sql } = require("../db");
const { requiereLogin } = require("../middleware/auth");
const asyncHandler = require("../utils/asyncHandler");

const router = express.Router();

router.get(
  "/pendientes",
  requiereLogin,
  asyncHandler(async (req, res) => {
    const pool = await getPool();

    const resultado = await pool
      .request()
      .input("tipo", sql.Int, 3)
      .execute("MAM_CreditosVentas");

    const pendientes = resultado.recordset.map((c) => ({
      creditoVentaId: c.Id,
      credito: c.Credito,
      venta: c.Venta,
      cliente: c.nombre,
      monto: c.Monto,
      abonado: c.abonado,
      restante: c.Restante,
      fechaVencimiento: c.FechaVencimientoCredito,
      diasMora: c.DiasMora,
      personalId: c.PersonalId,
    }));

    res.json(pendientes);
  })
);

router.post(
  "/",
  requiereLogin,
  asyncHandler(async (req, res) => {
    const { creditoVentaId, fechaPago, monto, nroRecibo, glosa, clienteId } = req.body;

    if (!creditoVentaId || !monto) {
      return res.status(400).json({
        error: "Faltan datos obligatorios: creditoVentaId y monto.",
      });
    }

    const pool = await getPool();

    const resultado = await pool
      .request()
      .input("tipo", sql.Int, 4)
      .input("CreditoVentaId", sql.Int, creditoVentaId)
      .input("PersonalId", sql.Int, req.usuario.idPersonal)
      .input("Glosa", sql.NVarChar(450), glosa ?? "")
      .input("FechaPago", sql.Date, fechaPago ?? new Date())
      .input("Monto", sql.Decimal(18, 2), monto)
      .input("NroRecibo", sql.NVarChar(50), nroRecibo ?? "")
      .input("ClienteId", sql.Int, clienteId ?? -1)
      .input("usuario", sql.NVarChar(50), req.usuario.nombreUsuario)
      .execute("MAM_CreditosVentas");

    const transaccionId = resultado.recordset?.[0]?.newNumi;

    res.status(201).json({ transaccionVentaId: transaccionId });
  })
);

module.exports = router;
