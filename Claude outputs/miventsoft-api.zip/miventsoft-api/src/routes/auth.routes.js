// auth.routes.js
// Login de la app movil.
//
// OJO - hallazgo de seguridad heredado del sistema actual:
// En AccesoLogica.vb (funcion L_Validar_Usuario), el login arma el SQL
// pegando el usuario y password directo en el texto de la consulta
// (concatenacion de strings), sin parametros. Eso es vulnerable a
// inyeccion SQL: alguien podria escribir un usuario/password especial
// para saltarse el login. Ademas, la contrasena esta guardada en texto
// plano en la tabla Usuarios (columna Contrasena) y se compara tal cual.
//
// Aqui SI usamos parametros (request.input) para eliminar la inyeccion.
// La comparacion la seguimos haciendo contra texto plano porque asi esta
// guardada la contrasena hoy en la base de datos real (no podemos migrar
// a un hash sin tambien cambiar el sistema de escritorio, que sigue
// escribiendo/leyendo esa misma columna en texto plano). Migrar a hash
// (bcrypt) es un cambio de base de datos + desktop que hay que planificar
// aparte, no algo que se pueda hacer solo en esta API sin romper el otro
// sistema.

const express = require("express");
const jwt = require("jsonwebtoken");
const { getPool, sql } = require("../db");
const asyncHandler = require("../utils/asyncHandler");

const router = express.Router();

router.post(
  "/login",
  asyncHandler(async (req, res) => {
    const { usuario, password } = req.body;

    if (!usuario || !password) {
      return res.status(400).json({ error: "Falta usuario o password." });
    }

    const pool = await getPool();

    const resultado = await pool
      .request()
      .input("nombreUsuario", sql.NVarChar(200), usuario)
      .input("password", sql.NVarChar(200), password)
      .query(`
        SELECT
          Id,
          RolId,
          SucursalId,
          IdPersonal,
          ISNULL(ModificarPrecioVenta, 0)      AS ModificarPrecioVenta,
          ISNULL(AplicarDescuentoVenta, 0)     AS AplicarDescuentoVenta,
          ISNULL(VerTodasVentas, 0)            AS VerTodasVentas,
          ISNULL(VerTodosVentasCierre, 0)      AS VerTodosVentasCierre,
          ISNULL(ModificarRegistroAnteriores, 0) AS ModificarRegistroAnteriores,
          ISNULL(
            (SELECT al.NombreAlmacen FROM Almacenes AS al WHERE al.Id = Usuarios.SucursalId),
            'Todos'
          ) AS NombreSucursal
        FROM Usuarios
        WHERE NombreUsuario = @nombreUsuario AND Contrasena = @password
      `);

    if (resultado.recordset.length === 0) {
      // Mensaje generico a proposito: no decimos si fallo el usuario o el
      // password, para no ayudar a alguien que este probando a adivinar.
      return res.status(401).json({ error: "Usuario o contrasena incorrectos." });
    }

    const u = resultado.recordset[0];

    // Este es el "payload" que va adentro del token. Cada request futura
    // de este usuario va a traer este token, y de aqui sacamos quien es
    // (reemplaza al viejo L_Usuario global).
    const payload = {
      id: u.Id,
      nombreUsuario: usuario,
      rolId: u.RolId,
      sucursalId: u.SucursalId,
      idPersonal: u.IdPersonal,
      permisos: {
        modificarPrecioVenta: !!u.ModificarPrecioVenta,
        aplicarDescuentoVenta: !!u.AplicarDescuentoVenta,
        verTodasVentas: !!u.VerTodasVentas,
        verTodosVentasCierre: !!u.VerTodosVentasCierre,
        modificarRegistroAnteriores: !!u.ModificarRegistroAnteriores,
      },
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || "12h",
    });

    res.json({
      token,
      usuario: {
        nombreUsuario: usuario,
        sucursalId: u.SucursalId,
        nombreSucursal: u.NombreSucursal,
        rolId: u.RolId,
        permisos: payload.permisos,
      },
    });
  })
);

module.exports = router;
