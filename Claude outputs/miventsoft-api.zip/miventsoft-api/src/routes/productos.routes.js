// productos.routes.js
// Lista de productos disponibles para vender (pantalla de venta /
// escaneo de codigo de barras en el celular).
//
// Usa el mismo SP que el sistema de escritorio: MAM_Ventas @tipo=5.
//
// *** LIMITACION HEREDADA DEL SISTEMA ACTUAL (ya existe en el desktop,
// no es un bug nuevo de esta API) ***
// Esa consulta usa INNER JOIN contra ProductosStock, Precios (x2) y
// ClasificadorDetalle. Eso significa que un producto NO va a aparecer
// en esta lista si le falta CUALQUIERA de estas cosas para ese deposito:
//   - Una fila en ProductosStock para el @SucursalId pedido (aunque sea stock 0,
//     tiene que EXISTIR la fila)
//   - Una fila de Precio de costo para la categoria de compra
//   - Una fila de Precio de venta para la @CategoriaVentaId pedida
//   - Un AttributoId (industria) asignado
// Es el mismo problema que ya detectamos antes en MAM_Movimientos con
// los productos migrados de ANABEL. Un producto nuevo sin todavia
// stock/precio/atributo cargado, simplemente no va a aparecer para
// venderse ni en el sistema de escritorio ni aqui. No lo estamos
// arreglando en esta API porque implicaria tocar el SP (logica de
// negocio compartida) - eso hay que decidirlo aparte.

const express = require("express");
const { getPool, sql } = require("../db");
const { requiereLogin } = require("../middleware/auth");
const asyncHandler = require("../utils/asyncHandler");

const router = express.Router();

router.get(
  "/venta",
  requiereLogin,
  asyncHandler(async (req, res) => {
    const sucursalId = Number(req.query.sucursalId ?? req.usuario.sucursalId);
    const categoriaVentaId = Number(req.query.categoriaVentaId);

    if (!sucursalId || !categoriaVentaId) {
      return res.status(400).json({
        error: "Faltan parametros: sucursalId y categoriaVentaId son obligatorios.",
      });
    }

    const pool = await getPool();

    const resultado = await pool
      .request()
      .input("tipo", sql.Int, 5)
      .input("SucursalId", sql.Int, sucursalId)
      .input("CategoriaVentaId", sql.Int, categoriaVentaId)
      .execute("MAM_Ventas");

    const productos = resultado.recordset.map((p) => ({
      id: p.Id,
      codigoExterno: p.CodigoExterno,
      nombre: p.NombreProducto,
      descripcion: p.DescripcionProducto,
      industria: p.industria,
      categoria: p.NombreCategoria,
      precioCosto: p.PrecioCosto,
      precioVenta: p.PrecioVenta,
      stock: p.stock,
      tipo: p.Tipo, // 1 = producto normal, 2 = kit
      nombreTipo: p.NombreTipo,
    }));

    res.json(productos);
  })
);

module.exports = router;
