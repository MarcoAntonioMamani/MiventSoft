// db.js
// Maneja UNA sola conexion (pool) hacia SQL Server, compartida por toda la API.
// Nunca escribimos usuario/password en logs ni en el codigo: todo sale de .env

const sql = require("mssql");

const config = {
  server: process.env.DB_SERVER,
  port: Number(process.env.DB_PORT) || 1433,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    // "true" solo si el certificado del servidor no es valido (comun en instancias caseras/dev).
    trustServerCertificate: process.env.DB_TRUST_SERVER_CERTIFICATE === "true",
    encrypt: true,
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
};

// Validacion basica al arrancar: si falta algo en .env, preferimos que la API
// no levante en vez de arrancar "a medias" y fallar de forma rara despues.
function validarConfig() {
  const faltantes = ["server", "database", "user", "password"].filter(
    (campo) => !config[campo]
  );
  if (faltantes.length > 0) {
    throw new Error(
      `Faltan variables de entorno para conectar a SQL Server: ${faltantes
        .map((f) => "DB_" + f.toUpperCase())
        .join(", ")}. Revisa tu archivo .env (mira .env.example como guia).`
    );
  }
}

let poolPromise = null;

// getPool() devuelve siempre el mismo pool ya conectado (lo crea una sola vez).
// Usar esto en vez de abrir una conexion nueva por cada consulta.
function getPool() {
  if (!poolPromise) {
    validarConfig();
    poolPromise = new sql.ConnectionPool(config)
      .connect()
      .then((pool) => {
        console.log("Conectado a SQL Server:", config.database);
        return pool;
      })
      .catch((err) => {
        // Reseteamos poolPromise para que el siguiente intento vuelva a conectar
        // en vez de quedar "pegado" con una promesa rota para siempre.
        poolPromise = null;
        // No logueamos err.message completo si pudiera incluir datos sensibles;
        // el mensaje de mssql normalmente es seguro (no incluye el password), pero
        // igual lo recortamos por las dudas.
        console.error("Error al conectar a SQL Server:", err.code || err.message);
        throw err;
      });
  }
  return poolPromise;
}

module.exports = { sql, getPool };
