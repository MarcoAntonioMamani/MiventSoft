// asyncHandler.js
// Envuelve una funcion de ruta "async" para que, si tira un error,
// Express lo capture solo y lo mande al manejador de errores central
// (server.js), en vez de que el proceso se caiga o quede colgado.
//
// Uso: router.get("/algo", asyncHandler(async (req, res) => { ... }))

function asyncHandler(fn) {
  return function (req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = asyncHandler;
